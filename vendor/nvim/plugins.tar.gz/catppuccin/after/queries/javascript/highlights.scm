;; extends
[
"export"
] @keyword.export
