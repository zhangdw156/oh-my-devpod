require("catppuccin").load()
